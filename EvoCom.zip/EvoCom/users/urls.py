from django.urls import path
from .views import index, user_profile, login_view, user_logout, register_view,login_page,complete_profile,save_profile,userindex,about,contacts,password_reset_request,reset_password

urlpatterns = [
    path('', index, name='index'),
    path('about/', about, name='about'),
    path('contacts', contacts, name='contacts'),
    path('profile/', user_profile, name='user_profile'),
    path('register/', register_view, name='register'),
    path('login/', login_page, name='login'),
    path('loginfn/', login_view, name='loginfn'),
    path('logout/', user_logout, name='logout'),
    path('complete-profile/', complete_profile, name='complete_profile'),
    path('save-profile/', save_profile, name='save_profile'),
    path('userindex/', userindex, name='userindex'),
    path('forgot_password/', password_reset_request, name='password_reset_request'),
    path('reset_password/<str:token>/', reset_password, name='reset_password'),
]
