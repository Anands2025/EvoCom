from django.core.mail import send_mail

send_mail(
    'Test Email',
    'This is a test email.',
    'evocomindia@gmail.com',
    ['anandsanthosh2017@gmail.com'],
    fail_silently=False,
)
