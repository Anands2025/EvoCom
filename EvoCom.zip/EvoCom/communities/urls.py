from django.urls import path
from .views import community_list, community_detail, create_community, join_community

urlpatterns = [
    path('', community_list, name='community_list'),
    path('<int:pk>/', community_detail, name='community_detail'),
    path('create/', create_community, name='create_community'),
    path('<int:pk>/join/', join_community, name='join_community'),
]
