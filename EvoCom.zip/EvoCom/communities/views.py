from django.shortcuts import render, get_object_or_404, redirect
from .models import Community
from .forms import CommunityForm

def community_list(request):
    communities = Community.objects.all()
    return render(request, 'communities/community_list.html', {'communities': communities})

def community_detail(request, pk):
    community = get_object_or_404(Community, pk=pk)
    return render(request, 'communities/community_detail.html', {'community': community})

def create_community(request):
    if request.method == 'POST':
        form = CommunityForm(request.POST)
        if form.is_valid():
            community = form.save()
            return redirect('community_detail', pk=community.pk)
    else:
        form = CommunityForm()
    return render(request, 'communities/create_community.html', {'form': form})

def join_community(request, pk):
    community = get_object_or_404(Community, pk=pk)
    community.members.add(request.user)
    return redirect('community_detail', pk=pk)
