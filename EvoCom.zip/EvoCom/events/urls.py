from django.urls import path
from .views import event_list, event_detail, create_event, register_for_event

urlpatterns = [
    path('', event_list, name='event_list'),
    path('<int:pk>/', event_detail, name='event_detail'),
    path('create/', create_event, name='create_event'),
    path('<int:pk>/register/', register_for_event, name='register_for_event'),
]
