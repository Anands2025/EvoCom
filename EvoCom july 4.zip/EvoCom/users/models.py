from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone
from datetime import timedelta
from django.utils.crypto import get_random_string

class User(AbstractUser):
    ROLE_CHOICES = [
        ('member', 'Community Member'),
        ('organizer', 'Event Organizer'),
        ('admin', 'Administrator'),
        ('community_admin', 'Community Admin'),
    ]
    
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    password_reset_token = models.CharField(max_length=100, blank=True, null=True)
    password_reset_token_expiry = models.DateTimeField(blank=True, null=True)

    def __str__(self):
        return self.username

    def set_password_reset_token(self):
        self.password_reset_token = get_random_string(length=32)
        self.password_reset_token_expiry = timezone.now() + timedelta(hours=1)
        self.save()

    def clear_password_reset_token(self):
        self.password_reset_token = None
        self.password_reset_token_expiry = None
        self.save()

    def is_password_reset_token_valid(self, token):
        if self.password_reset_token == token and self.password_reset_token_expiry > timezone.now():
            return True
        return False

# If you still want to use the PasswordResetToken model
